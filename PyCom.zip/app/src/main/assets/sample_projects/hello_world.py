# Hello World - Sample Python Script
# This file demonstrates basic Python syntax

print("Hello, World!")
print("Welcome to PyCom - Python IDE for Android")

# Variables
name = "PyCom User"
version = "1.0"

print(f"App: {name}")
print(f"Version: {version}")

# Simple calculation
x = 10
y = 20
result = x + y
print(f"{x} + {y} = {result}")
